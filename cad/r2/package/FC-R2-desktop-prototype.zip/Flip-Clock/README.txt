FC-R2 prototype: see cad/r2/README.md and RESULTS.md.
Run cad/r2/build.ps1 from this extracted Flip-Clock directory.
This package includes original project helper source, not third-party archive geometry.
Physics videos and raw solver evidence are published separately in cad/r2/review on the GitHub branch.
