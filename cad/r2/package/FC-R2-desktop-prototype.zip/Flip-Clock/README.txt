FC-R2 prototype: see cad/r2/README.md and RESULTS.md.
Run cad/r2/build.ps1 from this extracted Flip-Clock directory.
This package includes independently authored project helper source, not third-party archive geometry.
Current physics videos and raw solver evidence are in cad/r2/review_native on the GitHub branch; cad/r2/review preserves the failed historical baseline.
